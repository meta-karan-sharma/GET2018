package webService;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

public class Test {

	public static void main(String[] args) throws RemoteException, ServiceException {
		ConvertTempServiceLocator loc = new ConvertTempServiceLocator();
		System.out.println(loc.getConvertTemp().convertTemp(98.6f));

	}

}
