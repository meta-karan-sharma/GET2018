package webService;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class ConvertTemp {
	@WebMethod
	public float convertTemp(float f){
		return ((f-32)*5/9);
	}
}
