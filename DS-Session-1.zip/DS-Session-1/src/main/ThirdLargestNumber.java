package main;

public class ThirdLargestNumber {
	public int thirdLargestNumber (int[] array) {
		int a = Integer.MIN_VALUE;
		int b = a;
		int c = a;
		for (int i = 0; i < array.length; i++) {
			if(array[i] > a && array[i] < b){
				a = array[i];
			} else if(array[i] > b && array[i] < c) {
				a = b;
				b = array[i];
			} else if(array[i] > c) {
				a = b;
				b = c;
				c = array[i];
			}
		}
		
		return a;
	}
}
