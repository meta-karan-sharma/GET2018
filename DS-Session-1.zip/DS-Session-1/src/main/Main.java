package main;

public class Main {
	public static void main(String[] args){
		josephus(10, 5);
	}
	
	static void josephus (int n, int m) {
		int k = n;
		
		int[] arr = new int[n + 1];
		int i = m;
		while (k > 1) {
			if (i <= n){
				if (arr[i] == 0) { 
					arr[i] = 1;
					System.out.println("i" + i);
				} else {
					arr[++i] = 1;
					System.out.println("i" + i);
				}
			} else {
				i %= n;
				continue;
			}
			i += m;
			k--;
		}
	}
}