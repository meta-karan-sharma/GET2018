package assignment_4;
/*
 * Class for Node
 */
public class Node {
	
	Node previous;
	int data;
	Node next;
}
