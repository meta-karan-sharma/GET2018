package assignment_3;
/*
 * Class for Node
 */
public class Node {
	Node next;
	int data;
}
