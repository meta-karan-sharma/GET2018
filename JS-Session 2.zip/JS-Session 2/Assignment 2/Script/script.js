var string; //to globally store the received string input
var flag; //to let us know if there are any remaining duplicates

/*Method to display the original string with the option to remove duplicates*/
function createDiv()
{
	string = document.getElementById('string').value;
	var div = document.createElement('div');
	div.id = 'container';
	div.style.height = "1000px";
	div.style.width = "100%";
	document.body.appendChild(div);
	var div1 = document.createElement('div');
	div1.innerHTML = string + " <br/><br/><input type = 'button' value = 'Remove Duplicates' onclick = 'removeDuplicates()'><br/><br/>";
	div.appendChild(div1);
}

/*Method to display the string after every duplicate removal */
function removeDuplicates()
{
	var div = document.getElementById('container');
	var div1 = document.createElement('div');
	remove();
	if( !flag ) // duplicates found
	{
		div1.innerHTML = string + " <br/><br/><input type = 'button' value = 'Remove Duplicates' onclick = 'removeDuplicates()'><br/><br/>";
		div.appendChild(div1);
	}
	else 
		alert('all duplicates removed');
}

/*Method to remove the duplicates*/
function remove() 
{
	var length = string.length;
	var count = 0;
	for(i = 0; i < length; i++) 
	{
		if(string[i] == string[i+1]) //counts the number of consecutive duplicates
		{
			count++;
			continue;
		}
		if(count > 0) //removes the number of duplicates found
		{
			string = string.slice(0 ,i - count) + string.slice(i + 1 , length);
			count = 0;
			flag = false;
			break;
		}
		else // if no duplicates are found
		{
			flag = true;
		}
	}
}