var first = null; // initializing the
var last = null; // linked list

/*Method to create and add nodes to the list*/
function new_node() 
{
	var data = document.getElementById('data').value;
	if(data != "") 
	{
		var node = new Object();
		node.data = data;
		document.getElementById('data').value = "";
		node.next =  null;
		node.previous = last;
		if(first == null) 
		{
			first = node;
		}
		else 
		{
			last.next = node;
		}
		last = node;
	}
  
	else 
	{
		alert("data can't be empty");
	}
}

/*Method to create a div and add elements to it using next pointer*/
function printforward() 
{
	var temp = first;
	var el = document.getElementById('print');
	el.innerHTML = "";
	while(temp!=null)
	{
		var div = document.createElement("div");
		div.style.border = "solid 1px black";
		div.style.display = "inline-block";
		div.style.margin = "10px";
		div.style.padding = "10px";
		var t = document.createTextNode(temp.data);
		div.appendChild(t);
		el.appendChild(div);
		temp = temp.next;
	}
}
 
/*Method to create a div and add elements to it using previous pointer*/
function printbackward() 
{
    var temp = last;
	var el = document.getElementById('print');
	el.innerHTML = "";
    while(temp!=null)
	{
		var div = document.createElement("div");
		div.style.border = "solid 1px black";
		div.style.display = "inline-block";
		div.style.margin = "10px";
		div.style.padding = "10px";
		var t = document.createTextNode(temp.data);
		div.appendChild(t);
		el.appendChild(div);
		temp = temp.previous;
    }
}