function validateName() 
{
    var x = document.forms["myForm"]["name"].value;
    var letters = /^[A-Za-z]+$/;
    if (x == "") 
	{
        document.myForm.name.style="border: 1px solid red";
		document.getElementById('alertName').innerHTML="Please Enter Name";
        return false;
    }
	else if (x.length > 20)
    {
		document.myForm.name.style="border: 1px solid red";
		document.getElementById('alertName').innerHTML="Please Enter a shorter Name";
        return false;
    }  
	else if (!/^[a-zA-Z]*$/g.test(document.myForm.name.value)) 
	{
		document.myForm.name.style="border: 1px solid red";
		document.getElementById('alertName').innerHTML="Please Enter a valid Name";
        return false;
    }
	document.myForm.name.style="border: 1px solid #aaa";
	document.getElementById('alertName').innerHTML="";
    return true;
}

function validateEmail()
{
    var x = document.forms["myForm"]["mail"].value;
    if (x == "") 
	{		
		document.getElementById('alertMail').innerHTML="Please Enter an Email";
		document.myForm.mail.style="border: 1px solid red";
        return false;
    }
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(x))
	{
		
		document.myForm.mail.style="border: 1px solid #aaa";
		document.getElementById('alertMail').innerHTML="";
		return (true);
	}
	document.getElementById('alertMail').innerHTML="Please Enter a valid Email";
    document.myForm.mail.style="border: 1px solid red";
    return (false);
}


function validatePhoneNumber()
{
	var phoneno = /^\(?([1-9]{1})\)?([0-9]{9})$/;
	var x = document.forms["myForm"]["num"].value;
	if (x == "") 
	{
		document.getElementById('alertNumber').innerHTML="Please Enter a Contact Number";
		document.myForm.num.style="border: 1px solid red";
		return false;
    }
	else if(x.match(phoneno))
	{		
		document.myForm.num.style="border: 1px solid #aaa";
		document.getElementById('alertNumber').innerHTML="";
		return true;
	}
	else
	{
		document.getElementById('alertNumber').innerHTML="Please Enter a valid Contact Number";
		document.myForm.num.style="border: 1px solid red";
		return false;
	}
}
function validateOrgName()
{
	var x = document.forms["myForm"]["orgName"].value;
	if (x == "") 
	{
		document.getElementById('alertOrg').innerHTML="Please Enter an Organization Name";
		document.myForm.orgName.style="border: 1px solid red";
		return false;
    }
	if (!/^[a-zA-Z]*$/g.test(x)) 
	{
		document.getElementById('alertOrg').innerHTML="Please Enter a valid Organization Name";
		document.myForm.orgName.style="border: 1px solid red";
		return false;
	}
	document.myForm.orgName.style="border: 1px solid #aaa";
	document.getElementById('alertOrg').innerHTML="";
	return true;
}
  
function validateTextArea(value)
{
	if ( typeof validateTextArea.counter == 'undefined' ) 
	{
        validateTextArea.counter = 1;
    }
	document.getElementById('alertMessage').innerHTML = validateTextArea.counter + " / 250";
	if(value.length > 250) 
	{
		value = value.substring(0,250);
		document.getElementById('textarea').value = value;
	}
	var input = document.getElementById('textarea');

	input.onkeydown = function() {
		var key = event.keyCode || event.charCode;

		if( key == 8 || key == 46 )
		{
			if (validateTextArea.counter > 0)
				validateTextArea.counter--;
		}
		else
			validateTextArea.counter++;
	};
}
function validateCity(val)
{
	if(val == "")
	{
		document.getElementById('alertCity').innerHTML = "Please Select a City";
		return false;
	}
	else
	{
		var table = document.getElementById("form");

		var row = table.insertRow(3);

		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);

		cell1.innerHTML = "";
		cell2.innerHTML = "<input type = 'text' id = 'citydesc' style = 'width:300px' disabled>";
		document.getElementById('citydesc').value = "You have selected this city: "+ val;

		return true;
	}
}

function validateAllFields(ev)
{
	if (! (validateName () & validateEmail () & validatePhoneNumber () & validateOrgName () & validateTextArea (document.getElementById ('textarea').value) & validateCity (document.getElementById ('city').value) ) )
	{
		ev.preventDefault();
	}
}